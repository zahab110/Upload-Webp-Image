<?php
namespace UploadImage\Webp\Controller\Adminhtml\Wysiwyg\Images;

use Magento\Backend\App\Action;
use Magento\Framework\Controller\Result\RawFactory;
use Magento\Cms\Helper\Wysiwyg\Images as WysiwygImagesHelper;
use Magento\Framework\Filesystem;

class Thumbnail extends \Magento\Cms\Controller\Adminhtml\Wysiwyg\Images

{
/**
* @var RawFactory
*/
protected $resultRawFactory;

/**
* @var WysiwygImagesHelper
*/
protected $wysiwygImagesHelper;

/**
* @var Filesystem
*/
protected $filesystem;

/**
* @param Action\Context $context
* @param \Magento\Framework\Registry $coreRegistry
* @param RawFactory $resultRawFactory
* @param WysiwygImagesHelper $wysiwygImagesHelper
* @param Filesystem $filesystem
*/
public function __construct(
Action\Context $context,
\Magento\Framework\Registry $coreRegistry,
RawFactory $resultRawFactory,
WysiwygImagesHelper $wysiwygImagesHelper,
Filesystem $filesystem
) {
$this->resultRawFactory = $resultRawFactory;
$this->wysiwygImagesHelper = $wysiwygImagesHelper;
$this->filesystem = $filesystem;
parent::__construct($context, $coreRegistry);
}

/**
* Generate image thumbnail on the fly
*
* @return \Magento\Framework\Controller\Result\Raw
*/
public function execute()
{
$file = $this->getRequest()->getParam('file');
$file = $this->wysiwygImagesHelper->idDecode($file);
$thumb = $this->getStorage()->resizeOnTheFly($file);

/** @var \Magento\Framework\Controller\Result\Raw $resultRaw */
$resultRaw = $this->resultRawFactory->create();

if ($file) {
$extension = pathinfo($file, PATHINFO_EXTENSION);

if (strtolower($extension) === 'webp') {
$webpImagePath = 'wysiwyg/' . $file;
$this->processWebPImage($resultRaw, $webpImagePath);
} else {
$this->processNonWebPImage($resultRaw, $thumb);
}

return $resultRaw;
} else {
echo "File parameter is missing or invalid.";
}
}

/**
* Process WebP image
*
* @param \Magento\Framework\Controller\Result\Raw $resultRaw
* @param string $webpImagePath
*/
protected function processWebPImage($resultRaw, $webpImagePath)
{
$mediaDirectory = $this->filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
$absoluteFilePath = $mediaDirectory->getAbsolutePath($webpImagePath);

if ($mediaDirectory->isFile($absoluteFilePath)) {
$webpContents = $mediaDirectory->readFile($webpImagePath);
$resultRaw->setHeader('Content-Type', 'image/webp');
$resultRaw->setHeader('Content-Length', strlen($webpContents));
$resultRaw->setContents($webpContents);
} else {
// WebP image not found
$this->outputNotFoundMessage();
}
}

/**
* Process non-WebP image
*
* @param \Magento\Framework\Controller\Result\Raw $resultRaw
* @param string $thumb
*/
protected function processNonWebPImage($resultRaw, $thumb)
{
/** @var \Magento\Framework\Image\Adapter\AdapterInterface $image */
$image = $this->_objectManager->get(\Magento\Framework\Image\AdapterFactory::class)->create();
$image->open($thumb);
$resultRaw->setHeader('Content-Type', $image->getMimeType());
$resultRaw->setContents($image->getImage());
}

/**
* Output message for not found image
*/
protected function outputNotFoundMessage()
{
// Adjust this message based on your requirements
echo "WebP Image Not Found";
}
}